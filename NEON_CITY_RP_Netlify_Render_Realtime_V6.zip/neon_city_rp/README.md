# NEON CITY RP — Hesap, Kamera ve Sunucu Ayarları sürümü

## Başlatma
1. ZIP'i tamamen bir klasöre çıkartın.
2. `start.bat` dosyasını çalıştırın.
3. Tarayıcıda `http://127.0.0.1:8000` açılır.
4. İlk girişte **Hesap oluştur** seçeneğiyle kullanıcı adı ve en az 8 karakterli şifre belirleyin.

## Kontroller
- W: ileri
- S: geri
- A: sola
- D: sağa
- SHIFT: koş
- T: sohbet
- E: etkileşim
- ESC: duraklat / fare kilidini bırak
- Fare: oyun görüntüsüne tıklayıp imleci kilitleyin; fareyi hareket ettirerek kamerayı/baş yönünü çevirin. ESC ile serbest bırakın. İmleç kilidi istemezseniz sahnede basılı tutup sürükleyerek de kamerayı döndürebilirsiniz.
- Fare tekerleği: kamera mesafesi

## Sunucu ayarları
`server_settings.json` dosyasını `server.py` ile aynı klasörde düzenleyin. Değişikliklerin uygulanması için sunucuyu kapatıp yeniden başlatın.

Örnek:
```json
{
  "name": "NEON CITY RP",
  "region": "TÜRKİYE · ANA SUNUCU",
  "capacity": 64,
  "mode": "Serbest RP",
  "time_of_day": "evening",
  "weather": "clear",
  "day_cycle_minutes": 0
}
```

`time_of_day` seçenekleri: `morning`, `noon`, `evening`, `night`, `cycle`.
- morning: sabah
- noon: öğle
- evening: akşam
- night: gece
- cycle: bilgisayarın yerel saatine göre gün ışığı döngüsü

`capacity`: 1–256 arası oyuncu kapasitesi. `mode`: sunucu kartında görünen oyun modu. `name` ve `region`: sunucu listesinde görünen ad ve bölge.

## Hesap güvenliği
Hesaplar `accounts.json` içinde saklanır. Şifreler düz metin olarak tutulmaz; PBKDF2-HMAC-SHA256 ve rastgele salt ile hashlenir. Bu prototipte oturumlar sunucu belleğindedir; Python sunucusu yeniden başlatıldığında kullanıcıların tekrar giriş yapması gerekir. `accounts.json` dosyasını silmek tüm kayıtlı hesapları siler; yedekleyin.

## Önemli
Bu proje yerel ağ prototipidir. İnternete açık, herkese açık sunucuya çevirmeden önce HTTPS, rate limit, kalıcı oturum, yönetici paneli ve güvenlik sertleştirmesi gerekir. `weather` ayarı şu an yapılandırmada saklanır; görsel yağmur/hava efektleri henüz uygulanmamıştır.


## Şehir ekonomisi (V4)
- Hesap açıldığında 6.500 başlangıç parası verilir.
- Şehir menüsünden market, garaj, günlük görevler ve mini oyunlar açılır.
- Araçlar ve market eşyaları hesap dosyasında kalıcı saklanır. Araç satın alma vardır; araca binme/sürüş entegrasyonu sonraki aşamadır.
- Mini oyun ödülleri backend tarafından sabit ödül ve süre kontrolüyle verilir. Bu prototipte tam hile önleme/anti-cheat değildir.

## İnternette yayınlama
Netlify statik HTML/CSS/JS dosyalarını yayınlayabilir; bu projedeki sürekli çalışan Python HTTP oyun sunucusunu Netlify üzerinde çalıştıramaz. Netlify'ı istemci için, Python backend'i ise Render/Fly.io/Railway gibi sürekli çalışan bir Python hizmetinde (veya VPS üzerinde) barındırmak gerekir. Gerçek çok oyunculu kullanım öncesi SQLite/PostgreSQL veritabanı, HTTPS, kalıcı oturumlar, WebSocket tabanlı hareket senkronizasyonu, oran sınırlama ve güvenlik sertleştirmesi gerekir. Mevcut sunucu prototipi HTTP polling kullanır ve oyun sunucusu tek süreç içi bellekte oyuncu durumunu tutar; üretim ortamı değildir.


### Netlify + Render dağıtımı (ön hazırlık)
1. Projeyi GitHub deposuna yükle.
2. Netlify'da bu depoyu bağla; `netlify.toml` statik yayın klasörünü proje kökü olarak ayarlar.
3. `site/config.js` içindeki `window.NEON_API_BASE` değerini Render'da oluşturduğun backend adresiyle değiştir (sonunda `/` olmasın).
4. Aynı depodan Render'da Python Web Service oluştur. Build Command: `pip install -r requirements.txt` (bu projede ek paket gerekmeyebilir); Start Command: `python server.py`. Render `PORT` ortam değişkenini otomatik sağlar.
5. Render servisi hazır olunca `config.js` adresini güncelle ve Netlify'ı yeniden deploy et.

**Önemli:** Bu sürüm prototip amaçlıdır. Render'ın varsayılan dosya sistemi geçicidir; hesap verileri deploy/restart sonrasında kaybolmamalıysa kalıcı disk veya veritabanı kurulmalıdır. Şu an gerçek zamanlı hareket/sohbet WebSocket değil, HTTP polling kullanır. İnternete açmadan önce güvenlik, rate-limit, kalıcı oturum, veritabanı, CORS alan adı kısıtlaması ve anti-cheat geliştirmesi gerekir.


## V6 — Netlify + Render gerçek zamanlı çok oyunculu hazırlığı

Bu sürüm HTTP polling yerine WebSocket üzerinden oyuncu konumu ve sohbet yayınlayabilir. HTTP API, WebSocket ve hesap/ekonomi endpoint'leri aynı Python `server.py` sürecinde çalışır. WebSocket bağlantısı oyuncunun oturum belirteci, oyuncu kimliği ve sunucu kimliği ile doğrulanır. WebSocket kullanılamazsa istemci HTTP polling yedeğine döner.

### Ücretsiz yayın mimarisi

- **Netlify:** `site/` klasöründeki tarayıcı oyunu. `netlify.toml` yayın klasörünü ayarlar.
- **Render:** `render.yaml` ile Python API + WebSocket servisi. Render'da GitHub deposunu bağlayıp Blueprint olarak `render.yaml` dosyasını kullan.
- **Neon PostgreSQL:** Hesaplar, para, araçlar, envanter ve görev kayıtlarının Render'ın geçici dosya sisteminden etkilenmemesi için harici PostgreSQL kullan. Neon'da ücretsiz proje oluşturup bağlantı adresini Render ortam değişkeni `DATABASE_URL` olarak ekle. Bu değişken gizlidir; GitHub'a veya `config.js` içine koyma.

### Yayına alma sırası

1. Bu klasörün tamamını GitHub deposuna yükle.
2. Neon'da ücretsiz PostgreSQL projesi oluştur ve SSL içeren bağlantı adresini kopyala.
3. Render Dashboard → New → Blueprint ile depoyu bağla; `render.yaml` dosyası ücretsiz Web Service'i oluşturur.
4. Render servisi için `DATABASE_URL` değerini Neon bağlantı adresiyle doldur. `NEON_ALLOWED_ORIGINS` değerine Netlify site adresini (ör. `https://ornek-site.netlify.app`) yaz. İlk deploy öncesinde bilinmiyorsa boş bırakıp deploy sonrası doldur ve yeniden deploy et.
5. Render servisi `Live` olduğunda adresini kopyala. `site/config.js` içindeki `window.NEON_API_BASE` değerini `https://...onrender.com` adresinle değiştir.
6. GitHub'a commit/push yap. Netlify'da depoyu bağla; `netlify.toml` otomatik olarak `site/` klasörünü yayınlar.
7. Netlify sitesini aç; iki farklı tarayıcı/cihazdan iki hesapla giriş yapıp aynı sunucuya katılarak hareket ve sohbeti dene.

### Ücretsiz planın gerçek sınırları

- Render Free web servisi 15 dakika boyunca HTTP isteği veya mevcut WebSocket bağlantısından gelen mesaj almazsa uykuya geçer. Sonraki girişte yaklaşık bir dakika soğuk başlangıç beklenebilir. Oyuncu bağlıyken istemci 25 saniyede bir WebSocket ping mesajı yollar.
- Render Free servisinin dosya sistemi geçicidir; `accounts.json` güvenilir kalıcı depolama değildir. `DATABASE_URL` ile Neon PostgreSQL kullanılması önerilir. Neon Free da sınırsız/7-24 performans garantisi değildir; veritabanı 5 dakika boşta kalınca uykuya geçebilir ve ücretsiz kullanım/transfer limitleri vardır.
- WebSocket bağlantıları bakım, yeniden başlatma veya ağ kesintisinde kapanabilir; istemci otomatik yeniden bağlanmayı dener.
- Bu bir çok oyunculu prototiptir. Hareket koordinatları sunucuda sınırlandırılır fakat hız/teleport anti-cheat, moderasyon, spam/rate-limit, yönetici araçları ve ölçekleme henüz üretim seviyesinde değildir. Herkese açık yayına geçmeden önce bu katmanlar güçlendirilmelidir.
- Ücretsiz plan 7/24 kesintisiz erişim sağlamaz. Sürekli açık ve güvenilir RP sunucusu için ileride ücretli, sürekli çalışan bir servis gerekir.

### Yerelde çalıştırma

`start.bat` önceki gibi yerel sunucuyu başlatır. `site/config.js` yalnızca Netlify yayını içindir; yerel `server.py` kendi origin'inden API çağrısı yapar.
