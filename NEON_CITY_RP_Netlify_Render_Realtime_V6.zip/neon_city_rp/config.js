// Local play uses same-origin API. For Netlify, edit site/config.js instead.
window.NEON_API_BASE = '';
